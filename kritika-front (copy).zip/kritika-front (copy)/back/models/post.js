const mongoose = require('mongoose')

const postSchema = new mongoose.Schema({
  title: {
    type: String,
    required: [true, 'post title must be provided'],
  },
  content: {
    type: String,
    required: [true, 'post content must be provided'],
  },
  img: {
    type: String,
    default: ' ',
  },
  createdAt: {
    type: Date,
    default: Date.now(),
  },
  category: {
    type: String,
    enum: {
      values: ['travel', 'newletter', 'personaldevelopment'],
      message: '{VALUE} is not supported',
    },
    // enum: ['ikea', 'liddy', 'caressa', 'marcos'],
  },
})

module.exports = mongoose.model('Post', postSchema)
