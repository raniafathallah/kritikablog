require('dotenv').config();
require('express-async-errors');
const path=require('path');
const express = require('express');
const app = express();

const connectDB = require('./db/connect');
const postRoute=require('./routes/postRoute');
const notFoundMiddleware = require('./middleware/not-found');
const errorMiddleware = require('./middleware/error-handler');

// middleware
app.use(express.json());
app.use(express.static(__dirname + "/public"));

// routes

app.get('/', (req, res) => {
  res.send('<h1>Store API</h1><a href="/api/v1/posts">posts route</a>');
});

app.use('/api/v1/posts', postRoute);

// products route

app.use(notFoundMiddleware);
app.use(errorMiddleware);

const port = process.env.PORT || 5000;
 
if (process.env.NODE_ENV === 'production') {
  app.use(express.static(path.join(__dirname, '../frontend/build')));

  app.get('*', (req, res) =>
    res.sendFile(
      path.resolve(__dirname, '../', 'frontend', 'build', 'index.html')
    )
  );
} else {
  app.get('/', (req, res) => res.send('Please set to production'));
}


const start = async () => {
  try {
    // connectDB
    await connectDB(process.env.MONGO_URI);
    app.listen(port, () => console.log(`Server is listening port ${port}...`));
  } catch (error) {
    console.log(error);
  }
};

start();



