
// const Post = require('../models/post');
const testFun=(req,res)=>{
     // res.status(200).send("welcome");

}
const getAllPosts = async (req, res) => {
  const { category, sort ,_id} = req.query;
  const queryObject = {};

  if (category) {
    queryObject.category = category;
  }
  if(_id) {
    queryObject._id = _id;
  }
  let result = Post.find(queryObject);
  // sort
  if (sort) {
    result = result.sort('createdAt');
  }

  // const page = Number(req.query.page) || 1;
  // const limit = Number(req.query.limit) || 1;
  // const skip = (page - 1) * limit;

  // result = result.skip(skip).limit(limit);

  const posts = await result;
  res.status(200).json({ posts, nbHits: posts.length });
};

//const multer =require('multer');
const Post =require('../models/post');
//const upload = multer({ dest: './uploads' });


const createPost=async(req,res)=>{

          const newPost=new Post({
               title:req.body.title,
               content:req.body.content,
               img:req.body.img,
               category:req.body.category
          })
          newPost.save().then(()=>res.send("upload done ")).catch(err=>console.log(err));
          }

module.exports = {
     getAllPosts,
     createPost,
     testFun
};
