// import { createSlice, createAsyncThunk } from '@reduxjs/toolkit'
// import postService from './postService'



// export const getPosts = createAsyncThunk(
//   'posts/getPosts',
//   async (_, thunkAPI) => {
//     try {
//       return await postService.getPosts()
//     } catch (error) {
//       const message =
//         (error.response &&
//           error.response.data &&
//           error.response.data.message) ||
//         error.message ||
//         error.toString()
//       return thunkAPI.rejectWithValue(message)
//     }
//   }
// )

// const initialState = {
//   posts:[],
//   isError: false,
//   isSuccess: false,
//   isLoading: false,
//   message: '',
// }

// export const postSlice = createSlice({
//   name: 'post',
//   initialState,
//   reducers: {
//     reset: (state) => initialState,
//   },
//    extraReducers: (builder) => {
//     builder.addCase(getPosts.pending, (state) => {
//         state.isLoading = true
//       })
//       .addCase(getPosts.fulfilled, (state, action) => {
//         state.isLoading = false
//         state.isSuccess = true
//         state.posts = action.payload
//       })
//       .addCase(getPosts.rejected, (state, action) => {
//         state.isLoading = false
//         state.isError = true
//         state.message = action.payload
//       })
//   },
// })

// export const { reset } = postSlice.actions
// export default postSlice.reducer
