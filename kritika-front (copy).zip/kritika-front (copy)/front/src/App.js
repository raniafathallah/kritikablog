import './App.css';
import 'primeicons/primeicons.css';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Blog from './components/Blog';
import Shop from './components/Shop';
import BlogPost from './components/Tabview/BlogPost'

function App() {
  
  return (
    <>
      <Router>
        <div className='container-fluid'>
          <Routes>
          <Route path='/' element={<Blog />} />
            <Route path='/blog' element={<Blog />} />
            <Route path='/blog/:id' element={<BlogPost />} />
            <Route path='/shop' element={<Shop />} />
          </Routes>
        </div>
      </Router>
    </>
  )
}
export default App;




