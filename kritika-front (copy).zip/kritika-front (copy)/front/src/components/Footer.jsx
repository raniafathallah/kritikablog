import { useEffect } from "react";

const Footer=()=> {
     function reveal() {
          var reveals = document.querySelectorAll(".reveal");
          for (var i = 0; i < reveals.length; i++) {
          var windowHeight = window.innerHeight;
          var elementTop = reveals[i].getBoundingClientRect().top;
          var elementVisible = 100;
          if (elementTop < windowHeight - elementVisible) {
              reveals[i].classList.add("active");
          } else {
          // reveals[i].classList.remove("active");
          }
          }
      }

      useEffect(() => {
          reveal();
      }, []);

     return (
          <div className="footer-container reveal">
          

          <div className="footer-links"> 
               <a> HOME</a>
               <a> ABOUT</a>

               <a> COURSES</a>

               <a> SHOP</a>

               <a> BLOG</a>
               <a> CONTACT</a>
          </div>

          <div className='footer-social-icon' >
               <i className="pi pi-instagram social-media-icon" ></i>
               <i className="pi pi-facebook social-media-icon" ></i>
          
               <i className="pi pi-youtube social-media-icon" ></i>
    
               <i className="pi pi-twitter social-media-icon"></i>
          </div>

          <div className="img-btns">

               <div className="img-btn"> 
                  <a href="https://www.instagram.com/p/CkGXZHTpUHn/">
                    <i className="pi  pi-play social-media-icon"></i>
                  </a>
               </div>
               <div className="img-btn"> 
               </div>
               <div className="img-btn"> 
               </div>
               <div className="img-btn"> 
                    <a href="https://www.instagram.com/p/CkGXZHTpUHn/">
                         <i className="pi  pi-play social-media-icon"></i>
                    </a>
               </div>
               <div className="img-btn"> 
                    <a href="https://www.instagram.com/p/CkGXZHTpUHn/">
                         <i className="pi  pi-play social-media-icon"></i>
                    </a>
               </div>
               <div className="img-btn">   
                     <a href="https://www.instagram.com/p/CkGXZHTpUHn/">
                         <i className="pi  pi-play social-media-icon"></i>
                    </a>
                    

               </div>
               <div className="img-btn"> 
                    <a href="https://www.instagram.com/p/CkGXZHTpUHn/">
                         <i className="pi  pi-play social-media-icon"></i>
                    </a>

               </div>
               <div className="img-btn"> 
                    <a href="https://www.instagram.com/p/CkGXZHTpUHn/">
                         <i className="pi  pi-play social-media-icon"></i>
                    </a>
               </div>
          </div>

     

     <div className="all-rights"> 
              <strong>  © 2021 Kritika Goel  |  All Rights Reserved </strong></div>
          </div>
          );
        }
        
export default Footer;