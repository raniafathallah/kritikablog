import { InputText } from 'primereact/inputtext';
import { useEffect, useState } from 'react';
import { Button } from 'primereact/button';

const Email=()=> {

const[FirstName,setFirstName]=useState('FirstName');
const[LastName,setLastName]=useState('LastName');
const[EmailAdress,setEmailAdress]=useState('EmailAdress');

function reveal() {
     var reveals = document.querySelectorAll(".reveal");
     for (var i = 0; i < reveals.length; i++) {
     var windowHeight = window.innerHeight;
     var elementTop = reveals[i].getBoundingClientRect().top;
     var elementVisible = 100;
     if (elementTop < windowHeight - elementVisible) {
         reveals[i].classList.add("active");
     } else {
     // reveals[i].classList.remove("active");
     }
     }
 }
 useEffect(() => {
     setTimeout(() => {
          reveal();

     }, 500);
 }, []);
     return (
          <div className="email-container reveal">
               <div className="img-bar">
               <img src="./images/footer.jpg"/>

               </div>
               <div className="trial-bar">
                    <h3>JOIN THE TRIBE!</h3>
                    <p>
                    Join my newsletter where I talk about personal development, productivity, and tips
                     to up your YouTube and social media game.
                    </p>
                    <form>
                       
                         <InputText value={FirstName} onChange={(e) => setFirstName(e.target.value)} />
                         <InputText value={LastName} onChange={(e) => setLastName(e.target.value)} />
                         <InputText value={EmailAdress} onChange={(e) => setEmailAdress(e.target.value)} />
                        <div>
                        <Button style={{}} label="JOIN NOW!" />
                        </div>
                    </form>
               </div>
          </div>
          );
        }
        
export default Email;