

import { useEffect, useState } from 'react';
import TabViewDemo from './Tabview/TabViewDemo';
function Blog (){

return (
  <>
     <div className="App">
          <div className=' col-1'>
            <p className=' blog-logo'>             Kritika Goel </p>

            <i className="pi  pi-bars social-media-icon  " ></i>

          </div>
          <div className='col-2'>
            <TabViewDemo/>
          </div>
          <div className='col-1 right-bar' >
               <i className="pi pi-instagram social-media-icon" ></i>
               <i className="pi pi-facebook social-media-icon" ></i>
          
               <i className="pi pi-youtube social-media-icon" ></i>
    
               <i className="pi pi-twitter social-media-icon"></i>
               <button className="shop-btn" > <a href='/shop'> SHOP</a></button>
          </div>


     </div>
     </>
     );
   }
   
   export default Blog;
   