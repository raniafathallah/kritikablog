
import axios from "axios";
import { useParams } from "react-router-dom";
import 'primereact/resources/themes/lara-light-indigo/theme.css';
import 'primereact/resources/primereact.css';
import React, { useState,useEffect } from 'react';
import { TabView, TabPanel } from 'primereact/tabview';
import { Button } from 'primereact/button';
import './TabViewDemo.css';
import Footer from "../Footer";

const TabViewDemoPost = () => {
    const { id } = useParams();
const [ID,setId]=useState(id);

console.log(id);
const [post,setPost]=useState([]);
const [content,setContent]=useState([]);
    const API_URL = '/api/v1/posts?_id='+id;
    const fetchPost =async () => {
        const response = await axios
        .get(API_URL)
        .catch((err) => {
            console.log("Err: ", err);
        });
  
        setPost(response.data.posts[0]);
  

    };
    useEffect(() => {
    fetchPost();
    }, [ID]);
    useEffect(() => {
        setTimeout(() => {
            convertstringToMultiLines();
          //  setContent(c);
        }, 500);
   
        }, [post]);




    const [activeIndex1, setActiveIndex1] = useState(2);


    const style = {
        height: 1000,
 
      };


      const  convertstringToMultiLines=()=>{
      const str=post.content||'*';
      const arrStr =str.split("*");
      setContent(arrStr)
      }


    return (
    <>
        <div className="tabview-demo"  >
            <div className="card">
                <div className="pt-2 pb-4">
                    <Button onClick={() => setActiveIndex1(0)}  label="ABOUT" 
                            className= {` tab-button ${activeIndex1 === 0 ? "active-link" : "unactive"} `}
                    />
                    <Button onClick={() => setActiveIndex1(1)} label="COURSES"
                            className= {` tab-button ${activeIndex1 === 1 ? "active-link" : "unactive"} `}
                    />
                    <Button onClick={() => setActiveIndex1(2)}  label="BLOG"
                         className= {` tab-button ${activeIndex1 === 2 ? "active-link" : "unactive"} `}
                    />
                    <Button onClick={() => setActiveIndex1(3)}  label="RESOURCES " 
                         className= {` tab-button ${activeIndex1 === 3 ? "active-link" : "unactive"} `}
                    />
                    <Button onClick={() => setActiveIndex1(4)}   label="CONTACT " 
                         className= {` tab-button ${activeIndex1 === 4 ? "active-link" : "unactive"} `}
                    />
                </div>

                <TabView activeIndex={activeIndex1} onTabChange={(e) => setActiveIndex1(e.index)}>
                    <TabPanel header="">
                        <p>ABOUT.</p>
                    </TabPanel>
                    <TabPanel header="">
                        <p> COURSES.</p>
                    </TabPanel>
                    <TabPanel id="theblog" header=""  >
                        {post&&
                        <div className='blog-post-container' >

                                <div className='blog-post post-content  ' >
                                <h3>   {post.title} </h3>


{content.length > 0 &&<div>
                            {content.map((c,index) => (
                                <p key={index}>{c}</p>
                           

                            
                            ))}
                            </div>
          
          }


                        

                                </div>
                            
                        </div>
          
          } 
          <Footer/>


                    </TabPanel>
                    <TabPanel header="">
                        <p>   RESOURCES  </p>
                    </TabPanel>
                    <TabPanel header="">
                        <p>   CONTACT  </p>
                    </TabPanel>
                </TabView>
            </div>
        </div>
    </>
    )
}
                
export default TabViewDemoPost;