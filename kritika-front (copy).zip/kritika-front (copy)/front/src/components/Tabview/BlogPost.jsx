import 'primereact/resources/themes/lara-light-indigo/theme.css';
import 'primereact/resources/primereact.css';
import React from 'react';
import './TabViewDemo.css';


import TabViewDemoPost from './TabViewDemoPost';
const BlogPost = () => {
     return (
  <>
     <div className="App">
          <p className=' col-1 blog-logo'>
             Kritika Goel
          </p>
          <div className='col-2'>
          <TabViewDemoPost/>
          </div>
          <div className='col-1 right-bar' >
               <i className="pi pi-instagram social-media-icon" ></i>
               <i className="pi pi-facebook social-media-icon" ></i>
          
               <i className="pi pi-youtube social-media-icon" ></i>
    
               <i className="pi pi-twitter social-media-icon"></i>
               <button className="shop-btn" > <a href='/shop'> SHOP</a></button>
          </div>
     </div>
     </>
     );

}
                
export default BlogPost;


