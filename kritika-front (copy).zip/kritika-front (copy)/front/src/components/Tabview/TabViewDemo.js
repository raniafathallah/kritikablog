import 'primereact/resources/themes/lara-light-indigo/theme.css';
import 'primereact/resources/primereact.css';
import React, { useState,useEffect } from 'react';
import { TabView, TabPanel } from 'primereact/tabview';
import { Button } from 'primereact/button';
import './TabViewDemo.css';
import axios from 'axios'
import { useDispatch, useSelector } from "react-redux";
import { setPosts } from "../../redux/actions/postsActions"
import Email from '../Email';
import Footer from '../Footer';
const TabViewDemo = () => {
    const posts = useSelector((state) => state.allposts.posts);
    const dispatch = useDispatch();
    const [category,setCategory]=useState('')
    const API_URL = '/api/v1/posts';
    const fetchPosts =async () => {
        const response = await axios
        .get(API_URL)
        .catch((err) => {
            console.log("Err: ", err);
        });
        dispatch(setPosts(response.data.posts));
        console.log(posts);
    };
    useEffect(() => {
    fetchPosts();
    }, []);

    const fetchPostsByCate =async () => {
        if(category!=='all'){
            const response = await axios
            .get(API_URL+"?category="+category)
            .catch((err) => {
                console.log("Err: ", err);
            });
            dispatch(setPosts(response.data.posts));
        }
        else{
            fetchPosts();
        }
    };

    useEffect(() => {
        fetchPostsByCate();
    console.log("posts"+posts)
    }, [category]);
    useEffect(() => {
        reveal();
    }, [posts]);


    function reveal() {
        var reveals = document.querySelectorAll(".reveal");
        for (var i = 0; i < reveals.length; i++) {
        var windowHeight = window.innerHeight;
        var elementTop = reveals[i].getBoundingClientRect().top;
        var elementVisible = 100;
        if (elementTop < windowHeight - elementVisible) {
            reveals[i].classList.add("active");
        } else {
        reveals[i].classList.remove("active");
        }
        }
    }

    const animateMore = () => {
            reveal();
    };

    const [activeIndex1, setActiveIndex1] = useState(2);


    const style = {
        height: 800,
        overflow:"scroll",
        overflowX:"hidden",
      };

    return (
    <>
        <div className="tabview-demo"  >
            <div className="card">
                <div className="pt-2 pb-4">
                    <Button onClick={() => setActiveIndex1(0)}  label="ABOUT" 
                            className= {` tab-button ${activeIndex1 === 0 ? "active-link" : "unactive"} `}
                    />
                    <Button onClick={() => setActiveIndex1(1)} label="COURSES"
                            className= {` tab-button ${activeIndex1 === 1 ? "active-link" : "unactive"} `}
                    />
                    <Button onClick={() => setActiveIndex1(2)}  label="BLOG"
                         className= {` tab-button ${activeIndex1 === 2 ? "active-link" : "unactive"} `}
                    />
                    <Button onClick={() => setActiveIndex1(3)}  label="RESOURCES " 
                         className= {` tab-button ${activeIndex1 === 3 ? "active-link" : "unactive"} `}
                    />
                    <Button onClick={() => setActiveIndex1(4)}   label="CONTACT " 
                         className= {` tab-button ${activeIndex1 === 4 ? "active-link" : "unactive"} `}
                    />
                </div>

                <TabView activeIndex={activeIndex1} onTabChange={(e) => setActiveIndex1(e.index)}>
                    <TabPanel header="">
                        <p>ABOUT.</p>
                    </TabPanel>
                    <TabPanel header="">
                        <p> COURSES.</p>
                    </TabPanel>
                    <TabPanel id="theblog" header="" style={style} onScroll={()=>{animateMore()}} >
                        <p className='blog-title'>The Blog</p>
                         <div className='inner-tabs'>
                           <button className='tab-btn tab-btn-style' onClick={()=>{setCategory("all")}}> All </button>|
                           <button className='tab-btn tab-btn-style' onClick={()=>{setCategory("travel")}}> Travel </button>|
                           <button className='tab-btn tab-btn-style'  onClick={()=>{setCategory("newletter")}}> Newsletter </button>|
                           <button className='tab-btn tab-btn-style'  onClick={()=>{setCategory("personaldevelopment")}}> Personal Development </button>
                         </div>
                        {/*  mapping data  */}

                        {posts.length > 0 &&
                        <div className='blog-posts-container' >
                            {posts.map((post) => (
                                    <a href={"/blog/"+post._id+""} className="post-link" key={post._id}>

                                <div className='blog-post reveal ' >
                                        <img src={post.img} />
                                        <h3  >   {post.title} </h3>

                                </div>
                                </a>

                            
                            ))}
                        </div>
          
          } 

          <Email/>
          <Footer/>

                    </TabPanel>
                    <TabPanel header="">
                        <p>   RESOURCES  </p>
                    </TabPanel>
                    <TabPanel header="">
                        <p>   CONTACT  </p>
                    </TabPanel>
                </TabView>
            </div>

        </div>
    </>
    )
}
                
export default TabViewDemo;