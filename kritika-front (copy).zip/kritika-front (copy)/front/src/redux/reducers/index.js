import { combineReducers } from "redux";
import { postReducer } from "./postReducer";
const reducers = combineReducers({

  allposts:postReducer

});
export default reducers;
