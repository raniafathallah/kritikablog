export const ActionTypes = {

  SET_POSTS:"SET_POSTS",
};
