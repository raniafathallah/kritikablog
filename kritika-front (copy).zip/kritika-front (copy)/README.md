# kritikablog
